<div align="center">

<img src="./pack.png" width=128>

<h2>RTAsCustom</h2>

<h3>自用混搭材质包， 纯缝合+手改。 修改了一些材质为3d并且将gui的色彩变得更加丰富</h3>

</div>

# 目录

<!-- TOC -->
* [目录](#目录)
* [广告](#广告)
* [开源](#开源)
<!-- TOC -->


# 下载

> 点击 [这里](https://github.com/RTAkland/RTAsCustom/releases/latest)来获取最新版本

# 广告

> [团子小镇](https://www.dgtmc.top)是一个历史悠久的MC生电服务器， 从2016年发展至今。 团子小镇的Github链接: [DangoTown](https://github.com/DangoTown)  
> 如果不能访问团子小镇主页请点击[这里](https://www.dgtmc.cn)访问备用地址

# 开源

- 本项目以[Apache-2.0](./LICENSE)许可开源, 即:
    - 你可以直接使用该项目提供的功能, 无需任何授权
   
